<?php include('header.php'); ?>
<div class="content-wrapper">


    <div class="row">

        <div class="col-lg-12">
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p><strong>BUSINESS MODEL<br /> </strong>Startup Name</p>
            <p>State, City</p>
            <p>www.abcd.com</p>
            <p>&nbsp;&nbsp;</p>
            <p>Basic Information:</p>
            <table>
                <tbody>
                    <tr>
                        <td width="286">
                            <p>Startup Name:</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>Address</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>State</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>City</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>Zip Code</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>Business Established ( Month / Year )</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>Type of Marketplace</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                </tbody>
            </table>
            <p>&nbsp;</p>
            <p><strong>Elevator Pitch:</strong><br /> <strong>Mission Statement:</strong><br /> <strong>Short Term
                    Goal:</strong><br /> <strong>Long Term Goal:</strong></p>
            <p><strong>Contact Information:</strong></p>
            <table>
                <tbody>
                    <tr>
                        <td width="285">
                            <p>Telephone</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="285">
                            <p>Email Address</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="285">
                            <p>Website</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                </tbody>
            </table>
            <p>&nbsp;</p>
            <p>Legal Existence:</p>
            <p>Current Stage of Operation:</p>
            <p>&nbsp;</p>
            <p>Key Partners &amp; Promoters:</p>
            <table>
                <tbody>
                    <tr>
                        <td width="286">
                            <p>Founder&rsquo;s Name</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>Founder&rsquo;s Background</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>Co- Founder&rsquo;s Name ( 1)</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>Co- Founder&rsquo;s Background ( 1)</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>Co- Founder&rsquo;s Name ( 2)</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                    <tr>
                        <td width="286">
                            <p>Co- Founder&rsquo;s Background ( 2)</p>
                        </td>
                        <td width="280">
                            <p>&nbsp;</p>
                        </td>
                    </tr>
                </tbody>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>Value Propositions:</p>
            <ol>
                <li>What Industry do you server?</li>
                <li>Do you offer a product/service or both?</li>
                <li>Name of Product/Service/Other</li>
                <li>Description Product/Service/Other</li>
                <li>Which of your customer&rsquo;s problems are you helping to solve?</li>
                <li>Is it a problem or a need?</li>
                <li>What is the value you deliver to your customer?</li>
                <li>What is your promise to your customers?</li>
                <li>How do you make your product/service?</li>
                <li>Any proprietary feature that gives your offering competitive advantage</li>
            </ol>
            <p>Customer Segment:</p>
            <h4>For whom you are creating values? Describe your target customer<br /> <strong><br /> Total size of your
                    industry<br /> <br /> </strong>Customer Location:<br /> Customer Age:<br /> Customer Occupation:
            </h4>
            <p>&nbsp;</p>
            <ol>
                <li>Total size of the industry you are targeting?</li>
                <li>Describe your target customer</li>
                <li>How do you plan to get your first customer?</li>
                <li>How do you plan to retain them?</li>
                <li>Any feedback mechanism from customer?</li>
            </ol>
            <p>&nbsp;</p>
            <p>Distribution Channel:</p>
            <ol>
                <li>How does your value proposition reach your customer?</li>
                <li>How will you/do you market your product/service:</li>
                <li>Where can your customer use or buy your products or services?</li>
                <li>What methods of distribution will you use to sell your products and/or services?</li>
            </ol>
            <p>&nbsp;</p>
            <p>Revenue Stream:</p>
            <p>How will you generate income/revenue?</p>
            <p>&nbsp;</p>
            <p>Price/Cost Strategy:</p>
            <ol>
                <li>What is the pricing strategy of your competitors?</li>
                <li>Can free users bring you value?</li>
                <li>Is your product unique?</li>
                <li>How are you deciding the price of your offering?</li>
                <li>What is the direct cost per sale?</li>
                <li>What is the indirect cost per sale?</li>
                <li>Desired profit margin per sale?</li>
            </ol>
            <p>&nbsp;</p>
            <p>Competitive Analysis:</p>
            <p>List down your top three competitors &ndash;</p>
            <ol>
                <li>Competitors First</li>
                <li>Competitors Second</li>
                <li>Competitors Third</li>
            </ol>
            <p><br /> How you are different from these three?<br /> Do you have a cost advantage?<br /> Do you have a
                technology or user experience advantage?<br /> Why will customer will choose your product over your
                competitors?</p>
            <p>Key Resource:</p>
            <ol>
                <li>What types of resources do you require?</li>
                <li>How many total employees do you need?</li>
                <li>Any niche skills you need in your employees?</li>
                <li>Do you require a production unit?</li>
                <li>Do you require an office space?</li>
                <li>What kind of inventory you need to keep in hand?</li>
                <li>What is the average value of inventory?</li>
                <li>Have you arranged money to meet this resourcing requirement?</li>
            </ol>
            <p>&nbsp;</p>
            <p>Key Activity:</p>
            <p>What are the activities you perform every day to create value (product/service)?<br /> What are the
                activities you perform every day to deliver value (product/service)?<br /> Write down 5 most important
                activities you will do in next three months to create/deliver value?</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
        </div>

    </div>

</div>
<?php include('footer.php'); ?>