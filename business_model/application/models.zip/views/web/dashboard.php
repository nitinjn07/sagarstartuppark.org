<?php include('header.php'); ?>
<div class="content-wrapper">


    <div class="row" id="report">

        <div class="col-lg-12 mx-auto">
            <img src="<?=base_url('assets/images/model.gif');?>" class="img-fluid" />
        </div>


    </div>

</div>
<?php include('footer.php'); ?>